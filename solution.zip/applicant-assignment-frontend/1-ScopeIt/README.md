An intern in our department is working on a notification script and wrote the following snippet:

```
(function message() { 
    message = "Du mangler at udfylde adresse feltet.";
	alert(message);
}());
```

**Assignment:** Help the intern out by sending him an edited version of the snippet above to make the string appear in the alert.

*Assignment Files:* ```scopeit.js```