(function message() {
    var message = "Du mangler at udfylde adresse feltet.";
    alert(message);
}());
