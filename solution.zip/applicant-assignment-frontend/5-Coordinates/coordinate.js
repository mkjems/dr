function Coordinate(x, y) {
    if(arguments.length == 1 && typeof x === 'string'){
      var seed = x.replace(/\{/g,'').split('}')
      .map(function(str){
          return str.split(',');
      }).filter(function(val){
          return (val.length > 1)
      }).map(function(arr){
          return {
            x: parseInt(arr[0],10),
            y: parseInt(arr[1],10)
          }
      }).filter(function(obj){
        return (obj.x >0 && obj.x <= 50000 && obj.y >0 && obj.y <= 50000);
      }).reduce(function(acc, curVal){
        return {
            x: acc.x + curVal.x,
            y: acc.y + curVal.y
        };
      }, {x:0, y:0});
      this.x = seed.x;
      this.y = seed.y;
    } else {
      this.x = x;
      this.y = y;
    }
}

Coordinate.prototype.toString = function() {
    return '{' + this.x + ',' + this.y + '}';
};

Coordinate.prototype.valueOf = function() {
    return this.toString();
};

console.log(new Coordinate(new Coordinate(30, 90) + new Coordinate(70, 150000)).toString() === '{100,240}'); // Must return true.
