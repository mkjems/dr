var express = require('express');
var app = express()

const querystring = require('querystring');
const http = require('http');

app.get('/', function(req, res) {
    res.send('Hello World!')
})

// http://www.dr.dk/mu-online/api/1.3/list/view/lastchance?limit=5&offset=0&channel=dr1
app.get('/lastchance', function(req, res) {
    const uri = 'http://www.dr.dk/mu-online/api/1.3/list/view/lastchance';
    const queryStr = querystring.stringify({
        limit: req.query.limit,
        offset: req.query.offset,
        channel: req.query.channel
    });
    const endpoint = uri + '?' + queryStr;

    function respond(data){
      res.send(data);
    }
    http.get( endpoint, (res) => {
        const statusCode = res.statusCode;
        const contentType = res.headers['content-type'];

        let error;
        if (statusCode !== 200) {
            error = new Error(`Request Failed.\n` +
                `Status Code: ${statusCode}`);
        } else if (!/^application\/json/.test(contentType)) {
            error = new Error(`Invalid content-type.\n` +
                `Expected application/json but received ${contentType}`);
        }
        if (error) {
            console.log(error.message);
            // consume response data to free up memory
            res.resume();
            return;
        }

        res.setEncoding('utf8');
        let rawData = '';
        res.on('data', (chunk) => rawData += chunk);
        res.on('end', () => {
            try {
                let parsedData = JSON.parse(rawData);
                console.log(req.query.channel);
                respond( parsedData);
            } catch (e) {
                console.log(e.message);
            }
        });
    }).on('error', (e) => {
        console.log(`Got error: ${e.message}`);
    });
})

app.listen(3001, function() {
    console.log('Example app listening on port 3001!')
})
