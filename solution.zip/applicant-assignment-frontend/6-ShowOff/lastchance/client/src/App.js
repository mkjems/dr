import React, {Component} from 'react';
import './App.css';
import classNames from 'classnames';

const Show = ({title, imgSrc, key, PrimaryChannelSlug, PresentationUri}) => {
    return (
        <div key={key} className="show">
            <a href={PresentationUri}>
              <img key={key} aria-hidden="true" role="presentation" alt={title} src={imgSrc} className="showImage"/>
            </a>
              <div className="show_heading">
                  <a href={PresentationUri} className="show_heading_link">{title}</a>
              </div>
        </div>
    );
};

const Chooser = ({slug,name, onclick, isActive, key}) => {
    return (
      <li key={key}>
          <span
            className={classNames('chooser_item', { chooser_item_active: isActive })}
            onClick={onclick}
          >{name}</span>
      </li>
    );
}

class App extends Component {
    constructor(props) {
        super();
        this.state = {
            limit: 5,
            offset:0,
            channel:'all',
            shows: [],
            next: '/lastchance?limit=10&offset=0&channel='
        };
    }

    render() {
        const channels = [
          {name:'DR1', slug:'dr1'},
          {name:'DR2', slug:'dr2'},
          {name:'DR3', slug:'dr3'},
          {name:'DRK', slug:'dr-k'},
          {name:'Alle', slug:'all'},
        ];
        return (
            <div className="container">

                <div className="heading">
                    <h2 className="heading_text">Udløber snart</h2>
                    <ul className="heading_chooser">
                        {
                          channels.map((channel, index)=>Chooser({
                              onclick : this.reset_with_channel.bind(null, channel.slug),
                              name : channel.name,
                              isActive : channel.slug === this.state.channel,
                              key : index
                          }))
                        }
                    </ul>
                </div>

                <div className="shows">
                    {this.state.shows.map((show, index) => Show({
                      key: index,
                      title: show.SeriesTitle,
                      imgSrc: show.PrimaryImageUri + "?width=185&height=104",
                      PrimaryChannelSlug: show.PrimaryChannelSlug,
                      PresentationUri: show.PresentationUri
                    }))}
                </div>

                <div className="more" onClick={this.handle_show_more}>
                    <a href="" className="more_button">Vis flere</a>
                </div>
            </div>
        );
    }

    calculateUrl(limit, offset, channel) {
        if(channel === 'all'){
          channel = '';
        }
        return '/lastchance?channel=' + channel + '&limit=' + limit + '&offset=' + offset;
    }

    load_more_shows(channel, offset) {
        const that = this;
        fetch(this.calculateUrl(this.state.limit,(offset!==undefined)?offset:this.state.offset,channel||this.state.channel), {
          method: 'get'
        })
        .then(function(response) {
            response.json().then(function(data) {
              console.log(data);
              that.setState({
                  shows: that.state.shows.concat(data.Items),
                  offset: that.state.offset + that.state.limit
              });
            });
        })
        .catch(function(err) {
            // Error :(
        });
    }

    componentDidMount() {
        this.load_more_shows()
    }

    reset_with_channel = (channel) => {
      this.setState({
          channel: channel,
          shows: [],
          offset: 0
      });
      this.load_more_shows(channel,0);
    }

    handle_show_more = (e) => {
        e.preventDefault();
        this.load_more_shows()
    }
}

export default App;
