
This prototype consists of two parts

* A small nodejs server on port 3001, that makes the requests to DR.dk
* A client, written in React that is servered by webpacks dev server on port 3000. Api calls to dr.dk are proxied to port 3001

Follow these steps To view this protoype on your local machine.
First open a terminal

    cd lastchance/
    yarn install
    yarnpkg server

in another terminal window:

    cd lastchance/client
    yarn install
    yarnpkg start

Point your browser to http://localhost:3000/

This should have been built with a proper state management pattern like flux or redux, but I ran out of time, so this is a somewhat crude solution.

Features:
* Will query the correct DR endpoint to retrieve live data.
* Is mobile friendly
* Select a channel to only se shows from that channel or all channels
* Page through shows 5 shows at a time.
