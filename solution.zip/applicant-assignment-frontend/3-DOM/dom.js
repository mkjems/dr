$(el).on('click', function() {
    $(this).addClass('slide-in')
      .css('opacity', '1.0')
      .css('color', 'red')
      .css('width', '200px')
      .css('height', '200px');
    $('#secondary-content').css('display', 'none');
    var new_content = [];
    for (var i = 0; i < 100; i++) {
        new_content.push($("<li>"));
    }
    $('#main-content').append($('<ul>')).append(new_content);
});
